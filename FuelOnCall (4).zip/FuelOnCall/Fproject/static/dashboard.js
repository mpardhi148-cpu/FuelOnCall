document.addEventListener("DOMContentLoaded", function () {

    const newRequests =
        document.getElementById("newRequests");

    const completedOrders =
        document.getElementById("completedOrders");

    const currentDelivery =
        document.getElementById("currentDelivery");

    const todayEarnings =
        document.getElementById("todayEarnings");

    const notificationBadge =
        document.getElementById("notificationBadge");

    let updating = false;
    let firstLoad = true;
    let previousNewRequests = 0;
    let previousCurrentDeliveries = 0;


    // =====================================================
    // FIND QUICK ACCESS BADGE
    // =====================================================

    function getQuickBadge(urlParts) {

        const cards =
            document.querySelectorAll(".quick-card");

        for (const card of cards) {

            const href =
                card.getAttribute("href") || "";

            if (
                urlParts.some(part =>
                    href.includes(part)
                )
            ) {
                return card.querySelector(".badge");
            }
        }

        return null;
    }


    const requestsBadge =
        getQuickBadge([
            "/petrol_requests",
            "/fuel_requests"
        ]);

    const deliveriesBadge =
        getQuickBadge([
            "/current_deliveries",
            "/current-deliveries"
        ]);


    // =====================================================
    // NUMBER UPDATE
    // =====================================================

    function setNumber(element, value) {

        if (!element) return;

        const number = Number(value);

        element.textContent =
            Number.isFinite(number)
                ? number
                : 0;
    }


    // =====================================================
    // NOTIFICATION POPUP
    // =====================================================

    function showNotification(message) {

        let notification =
            document.getElementById(
                "liveOrderNotification"
            );

        if (!notification) {

            notification =
                document.createElement("div");

            notification.id =
                "liveOrderNotification";

            notification.style.position =
                "fixed";

            notification.style.top =
                "70px";

            notification.style.right =
                "20px";

            notification.style.zIndex =
                "99999";

            notification.style.background =
                "#16a34a";

            notification.style.color =
                "#ffffff";

            notification.style.padding =
                "14px 18px";

            notification.style.borderRadius =
                "12px";

            notification.style.fontWeight =
                "bold";

            notification.style.boxShadow =
                "0 5px 20px rgba(0,0,0,.25)";

            notification.style.maxWidth =
                "320px";

            notification.style.display =
                "none";

            document.body.appendChild(
                notification
            );
        }

        notification.textContent =
            "🔔 " + message;

        notification.style.display =
            "block";

        clearTimeout(
            notification._timer
        );

        notification._timer =
            setTimeout(function () {

                notification.style.display =
                    "none";

            }, 5000);
    }


    // =====================================================
    // LIVE DASHBOARD
    // =====================================================

    async function updateDashboard() {

        if (updating) return;

        updating = true;

        try {

            const response =
                await fetch(
                    "/petrol_dashboard_api?t=" +
                    Date.now(),
                    {
                        method: "GET",
                        cache: "no-store",
                        credentials: "same-origin",
                        headers: {
                            "Accept":
                                "application/json",
                            "Cache-Control":
                                "no-cache",
                            "Pragma":
                                "no-cache"
                        }
                    }
                );


            if (!response.ok) return;


            const data =
                await response.json();


            if (
                !data ||
                data.success !== true
            ) {
                return;
            }


            // =================================================
            // COUNTS
            // =================================================

            const newRequestCount =
                Number(
                    data.new_requests || 0
                );

            const completedCount =
                Number(
                    data.completed_orders || 0
                );

            const currentDeliveryCount =
                Number(
                    data.current_delivery_count ??
                    data.current_deliveries ??
                    0
                );

            const earnings =
                Number(
                    data.today_earnings || 0
                );


            // =================================================
            // TOP DASHBOARD
            // =================================================

            setNumber(
                newRequests,
                newRequestCount
            );

            setNumber(
                completedOrders,
                completedCount
            );

            setNumber(
                currentDelivery,
                currentDeliveryCount
            );


            if (todayEarnings) {

                todayEarnings.textContent =
                    "₹" +
                    earnings.toFixed(2);
            }


            // =================================================
            // QUICK CARDS
            // =================================================

            setNumber(
                requestsBadge,
                newRequestCount
            );

            setNumber(
                deliveriesBadge,
                currentDeliveryCount
            );


            // =================================================
            // TOP NOTIFICATION NUMBER
            // =================================================

            if (notificationBadge) {

                notificationBadge.textContent =
                    newRequestCount;

                notificationBadge.style.display =
                    newRequestCount > 0
                        ? ""
                        : "none";
            }


            // =================================================
            // NEW ORDER NOTIFICATION
            // =================================================

            if (
                !firstLoad &&
                newRequestCount >
                previousNewRequests
            ) {

                const difference =
                    newRequestCount -
                    previousNewRequests;

                showNotification(
                    difference === 1
                        ? "New fuel order received."
                        : difference +
                          " new fuel orders received."
                );
            }


            // =================================================
            // NEW CURRENT DELIVERY
            // =================================================

            if (
                !firstLoad &&
                currentDeliveryCount >
                previousCurrentDeliveries
            ) {

                showNotification(
                    "New delivery has been added to Current Deliveries."
                );
            }


            previousNewRequests =
                newRequestCount;

            previousCurrentDeliveries =
                currentDeliveryCount;

            firstLoad = false;


        } catch (error) {

            console.error(
                "Petrol dashboard live update error:",
                error
            );

        } finally {

            updating = false;
        }
    }


    // =====================================================
    // FIRST UPDATE
    // =====================================================

    updateDashboard();


    // =====================================================
    // LIVE UPDATE EVERY 2 SECONDS
    // =====================================================

    setInterval(
        updateDashboard,
        2000
    );


    // =====================================================
    // TAB RETURN
    // =====================================================

    document.addEventListener(
        "visibilitychange",
        function () {

            if (
                document.visibilityState ===
                "visible"
            ) {
                updateDashboard();
            }
        }
    );

});