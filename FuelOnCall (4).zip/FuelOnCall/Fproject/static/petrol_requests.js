document.addEventListener(
    "DOMContentLoaded",
    function () {

        const REFRESH_INTERVAL = 2000;

        let loading = false;


        // =====================================================
        // HTML ESCAPE
        // =====================================================

        function escapeHtml(value) {

            if (
                value === null ||
                value === undefined
            ) {

                return "";

            }


            return String(value)

                .replace(/&/g, "&amp;")

                .replace(/</g, "&lt;")

                .replace(/>/g, "&gt;")

                .replace(/"/g, "&quot;")

                .replace(/'/g, "&#039;");

        }


        // =====================================================
        // GET ORDER STATUS
        // =====================================================

        function getStatus(order) {

            if (
                Number(order.cancelled) === 1
            ) {

                return {

                    text:
                        order.status ||
                        "Cancelled",

                    className:
                        "rejected"

                };

            }


            if (
                Number(order.accepted) === 1
            ) {

                return {

                    text:
                        order.delivery_status ||
                        order.status ||
                        "Accepted",

                    className:
                        "accepted"

                };

            }


            return {

                text:
                    order.status ||
                    "Pending Approval",

                className:
                    "pending"

            };

        }


        // =====================================================
        // CREATE ORDER CARD
        // =====================================================

        function createOrderCard(order) {

            const id =
                escapeHtml(
                    order.id
                );


            const status =
                getStatus(
                    order
                );


            const customer =
                escapeHtml(
                    order.customer_email
                );


            const fuel =
                escapeHtml(
                    order.fuel
                );


            const quantity =
                escapeHtml(
                    order.quantity
                );


            const price =
                escapeHtml(
                    order.price
                );


            const phone =
                escapeHtml(
                    order.phone
                );


            const address =
                escapeHtml(
                    order.address
                );


            const paymentStatus =
                escapeHtml(
                    order.payment_status
                );


            let actionHtml = "";


            // =================================================
            // PENDING ORDER
            // =================================================

            if (
                Number(order.accepted) === 0 &&
                Number(order.cancelled) === 0
            ) {

                actionHtml = `

                    <div class="status pending">

                        ⏳ Pending Approval

                    </div>


                    <div class="button-area">

                        <button
                            type="button"
                            class="btn accept js-accept-order"
                            data-order-id="${id}"
                        >

                            ✅ Accept Order

                        </button>


                        <button
                            type="button"
                            class="btn reject js-reject-order"
                            data-order-id="${id}"
                        >

                            ❌ Reject Order

                        </button>

                    </div>

                `;

            }


            // =================================================
            // ACCEPTED ORDER
            // =================================================

            else if (
                Number(order.accepted) === 1 &&
                Number(order.cancelled) === 0
            ) {

                actionHtml = `

                    <div class="status accepted">

                        ✅ ${
                            escapeHtml(
                                order.delivery_status ||
                                order.status ||
                                "Accepted"
                            )
                        }

                    </div>

                `;

            }


            // =================================================
            // CANCELLED ORDER
            // =================================================

            else {

                actionHtml = `

                    <div class="status rejected">

                        ❌ ${
                            escapeHtml(
                                order.status ||
                                "Cancelled"
                            )
                        }

                    </div>

                `;

            }


            // =================================================
            // CALL CUSTOMER
            // =================================================

            const callHtml =
                phone
                    ? `

                        <div class="call-area">

                            <a
                                href="tel:${phone}"
                                class="btn call"
                            >

                                📞 Call Customer

                            </a>

                        </div>

                    `
                    : "";


            return `

                <div
                    class="card new-order"
                    data-order-id="${id}"
                >

                    <h2>

                        Order #FOC${id}

                    </h2>


                    <div class="row">

                        <span class="label">
                            Customer:
                        </span>

                        ${customer}

                    </div>


                    <div class="row">

                        <span class="label">
                            Fuel:
                        </span>

                        ${fuel}

                    </div>


                    <div class="row">

                        <span class="label">
                            Quantity:
                        </span>

                        ${quantity} L

                    </div>


                    <div class="row">

                        <span class="label">
                            Amount:
                        </span>

                        ₹${price}

                    </div>


                    <div class="row">

                        <span class="label">
                            Phone:
                        </span>

                        ${phone || "Not available"}

                    </div>


                    <div class="row">

                        <span class="label">
                            Address:
                        </span>

                        ${address}

                    </div>


                    <div class="row">

                        <span class="label">
                            Payment Status:
                        </span>

                        ${paymentStatus || "Pending"}

                    </div>


                    <div class="row">

                        <span class="label">
                            Order Status:
                        </span>

                        <span class="order-status">

                            ${escapeHtml(
                                status.text
                            )}

                        </span>

                    </div>


                    ${callHtml}


                    ${actionHtml}


                </div>

            `;

        }


        // =====================================================
        // RENDER ORDERS
        // =====================================================

        function renderOrders(
            orders
        ) {

            const container =
                document.getElementById(
                    "ordersList"
                );


            if (!container) {

                console.error(
                    "ordersList not found"
                );

                return;

            }


            if (
                !Array.isArray(orders) ||
                orders.length === 0
            ) {

                container.innerHTML = `

                    <div class="empty">

                        <div class="empty-icon">

                            ⛽

                        </div>


                        <h3>

                            No Fuel Requests Available

                        </h3>


                        <p
                            style="margin-top:10px;"
                        >

                            New customer requests
                            will appear here.

                        </p>

                    </div>

                `;


                container.dataset.renderedHtml =
                    "";


                return;

            }


            const newHtml =
                orders
                    .map(
                        function (order) {

                            return createOrderCard(
                                order
                            );

                        }
                    )
                    .join("");


            if (
                container.dataset.renderedHtml !==
                newHtml
            ) {

                container.innerHTML =
                    newHtml;


                container.dataset.renderedHtml =
                    newHtml;

            }

        }


        // =====================================================
        // FETCH LIVE ORDERS
        // =====================================================

        async function refreshOrders() {

            if (loading) {
                return;
            }


            loading = true;


            try {

                const response =
                    await fetch(
                        "/petrol_orders_api?t=" +
                        Date.now(),
                        {

                            method:
                                "GET",

                            cache:
                                "no-store",

                            credentials:
                                "same-origin",

                            headers: {

                                "Accept":
                                    "application/json",

                                "Cache-Control":
                                    "no-cache",

                                "Pragma":
                                    "no-cache"

                            }

                        }
                    );


                if (!response.ok) {

                    console.error(
                        "petrol_orders_api:",
                        response.status
                    );

                    return;

                }


                const data =
                    await response.json();


                if (
                    data &&
                    data.success === true
                ) {

                    renderOrders(
                        data.orders || []
                    );

                }


            } catch (error) {

                console.error(
                    "Live order error:",
                    error
                );

            } finally {

                loading = false;

            }

        }


        // =====================================================
        // ACCEPT ORDER
        // =====================================================

        async function acceptOrder(
            orderId,
            button
        ) {

            button.disabled =
                true;


            button.textContent =
                "Accepting...";


            try {

                const response =
                    await fetch(
                        "/accept_order/" +
                        encodeURIComponent(
                            orderId
                        ),
                        {

                            method:
                                "POST",

                            credentials:
                                "same-origin",

                            headers: {

                                "X-Requested-With":
                                    "XMLHttpRequest",

                                "Accept":
                                    "application/json"

                            }

                        }
                    );


                const data =
                    await response.json();


                if (
                    !response.ok ||
                    !data.success
                ) {

                    throw new Error(
                        data.message ||
                        "Unable to accept order"
                    );

                }


                await refreshOrders();


            } catch (error) {

                console.error(
                    "Accept order error:",
                    error
                );


                alert(
                    error.message ||
                    "Unable to accept order."
                );


                button.disabled =
                    false;


                button.textContent =
                    "✅ Accept Order";

            }

        }


        // =====================================================
        // REJECT ORDER
        // =====================================================

        async function rejectOrder(
            orderId,
            button
        ) {

            const confirmed =
                window.confirm(
                    "Are you sure you want to reject this order?"
                );


            if (!confirmed) {
                return;
            }


            button.disabled =
                true;


            button.textContent =
                "Rejecting...";


            try {

                const response =
                    await fetch(
                        "/reject_order/" +
                        encodeURIComponent(
                            orderId
                        ),
                        {

                            method:
                                "POST",

                            credentials:
                                "same-origin",

                            headers: {

                                "X-Requested-With":
                                    "XMLHttpRequest",

                                "Accept":
                                    "application/json"

                            }

                        }
                    );


                const data =
                    await response.json();


                if (
                    !response.ok ||
                    !data.success
                ) {

                    throw new Error(
                        data.message ||
                        "Unable to reject order"
                    );

                }


                await refreshOrders();


            } catch (error) {

                console.error(
                    "Reject order error:",
                    error
                );


                alert(
                    error.message ||
                    "Unable to reject order."
                );


                button.disabled =
                    false;


                button.textContent =
                    "❌ Reject Order";

            }

        }


        // =====================================================
        // CLEAR PETROL REQUESTS
        // =====================================================

        const clearButton =
            document.getElementById(
                "clearRequestsButton"
            );


        if (clearButton) {

            clearButton.addEventListener(
                "click",
                async function () {

                    const confirmed =
                        window.confirm(
                            "Are you sure you want to clear all fuel requests?"
                        );


                    if (!confirmed) {
                        return;
                    }


                    clearButton.disabled =
                        true;


                    clearButton.textContent =
                        "Clearing...";


                    try {

                        const response =
                            await fetch(
                                "/pump-clear-orders",
                                {

                                    method:
                                        "POST",

                                    credentials:
                                        "same-origin",

                                    cache:
                                        "no-store",

                                    headers: {

                                        "X-Requested-With":
                                            "XMLHttpRequest",

                                        "Accept":
                                            "application/json",

                                        "Content-Type":
                                            "application/json"

                                    },

                                    body:
                                        JSON.stringify({})

                                }
                            );


                        const data =
                            await response.json();


                        if (
                            !response.ok ||
                            !data.success
                        ) {

                            throw new Error(
                                data.message ||
                                "Unable to clear requests."
                            );

                        }


                        // -----------------------------------------
                        // CLEAR SCREEN IMMEDIATELY
                        // -----------------------------------------

                        const container =
                            document.getElementById(
                                "ordersList"
                            );


                        if (container) {

                            container.innerHTML = `

                                <div class="empty">

                                    <div class="empty-icon">
                                        ⛽
                                    </div>


                                    <h3>
                                        No Fuel Requests Available
                                    </h3>


                                    <p
                                        style="margin-top:10px;"
                                    >
                                        New customer requests
                                        will appear here.
                                    </p>

                                </div>

                            `;


                            container.dataset.renderedHtml =
                                "";

                        }


                        // -----------------------------------------
                        // REFRESH FROM SERVER
                        // -----------------------------------------

                        await refreshOrders();


                    } catch (error) {

                        console.error(
                            "Clear requests error:",
                            error
                        );


                        alert(
                            error.message ||
                            "Unable to clear requests."
                        );

                    } finally {

                        clearButton.disabled =
                            false;


                        clearButton.textContent =
                            "🗑️ Clear";

                    }

                }
            );

        }


        // =====================================================
        // BUTTON EVENTS
        // =====================================================

        document.addEventListener(
            "click",
            function (event) {

                const acceptButton =
                    event.target.closest(
                        ".js-accept-order"
                    );


                if (acceptButton) {

                    const orderId =
                        acceptButton.dataset.orderId;


                    acceptOrder(
                        orderId,
                        acceptButton
                    );


                    return;

                }


                const rejectButton =
                    event.target.closest(
                        ".js-reject-order"
                    );


                if (rejectButton) {

                    const orderId =
                        rejectButton.dataset.orderId;


                    rejectOrder(
                        orderId,
                        rejectButton
                    );

                }

            }
        );


        // =====================================================
        // START
        // =====================================================

        refreshOrders();


        setInterval(
            refreshOrders,
            REFRESH_INTERVAL
        );

    }
);