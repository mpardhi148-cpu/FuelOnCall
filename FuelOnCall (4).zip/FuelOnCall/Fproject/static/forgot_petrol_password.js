
document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("forgotPasswordForm");
    const message = document.getElementById("formMessage");

    form.addEventListener("submit", function (event) {
        const username = document.getElementById("username").value.trim();
        const phone = document.getElementById("phone").value.trim();
        const password = document.getElementById("new_password").value;

        if (!username || !phone || !password) {
            event.preventDefault();
            message.textContent = "Please fill in all fields.";
            return;
        }

        if (password.length < 6) {
            event.preventDefault();
            message.textContent = "Password must be at least 6 characters.";
            return;
        }

        message.textContent = "Submitting password reset request...";
        // Form POST automatically app.py ke Flask route par jayega.
    });
});
