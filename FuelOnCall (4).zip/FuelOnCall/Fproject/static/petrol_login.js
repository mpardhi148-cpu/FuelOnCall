function validate(){

let email=document.getElementById("email").value.trim();

let password=document.getElementById("password").value.trim();

if(email==""){

alert("Please Enter Email");

return false;

}

if(password==""){

alert("Please Enter Password");

return false;

}

return true;

}

function showPassword(){

let pass=document.getElementById("password");

if(pass.type=="password"){

pass.type="text";

}
else{

pass.type="password";

}

}