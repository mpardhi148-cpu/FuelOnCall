document.addEventListener(
    "DOMContentLoaded",
    function () {


        // =================================================
        // STATE
        // =================================================

        let currentPeriod = 7;


        const ordersList =
            document.getElementById(
                "ordersList"
            );


        const orderCount =
            document.getElementById(
                "orderCount"
            );


        const downloadButton =
            document.getElementById(
                "downloadButton"
            );


        const clearButton =
            document.getElementById(
                "clearButton"
            );


        const periodButtons =
            document.querySelectorAll(
                ".period-btn"
            );


        // =================================================
        // LOAD ORDERS
        // =================================================

        async function loadOrders() {

            ordersList.innerHTML =
                `
                <div class="empty">
                    Loading Order History...
                </div>
                `;


            try {

                const response =
                    await fetch(
                        "/api/pump-order-history?period=" +
                        currentPeriod +
                        "&t=" +
                        Date.now(),
                        {
                            method: "GET",

                            credentials:
                                "same-origin",

                            cache: "no-store",

                            headers: {
                                "Accept":
                                    "application/json"
                            }
                        }
                    );


                const data =
                    await response.json();


                if (
                    !response.ok ||
                    data.success !== true
                ) {

                    throw new Error(
                        data.message ||
                        "Unable to load orders."
                    );

                }


                renderOrders(
                    data.orders
                );


                orderCount.textContent =
                    data.count +
                    " order(s) found";

            } catch (error) {

                console.error(
                    "History error:",
                    error
                );


                ordersList.innerHTML =
                    `
                    <div class="empty">
                        Unable to load order history.
                    </div>
                    `;


                orderCount.textContent =
                    "Unable to load orders.";

            }

        }


        // =================================================
        // RENDER ORDERS
        // =================================================

        function renderOrders(
            orders
        ) {

            ordersList.innerHTML =
                "";


            if (
                !Array.isArray(orders) ||
                orders.length === 0
            ) {

                ordersList.innerHTML =
                    `
                    <div class="empty">

                        <div style="font-size:45px;">
                            📦
                        </div>

                        <h3>
                            No Orders
                        </h3>

                        <p>
                            No orders found for the selected period.
                        </p>

                    </div>
                    `;

                return;

            }


            orders.forEach(
                function (order) {

                    const card =
                        document.createElement(
                            "div"
                        );


                    card.className =
                        "order-card";


                    card.innerHTML =
                        `
                        <h3>
                            Order #${escapeHtml(
                                order.id
                            )}
                        </h3>

                        <div class="row">
                            <span class="label">
                                Customer:
                            </span>
                            ${escapeHtml(
                                order.customer_email ||
                                "-"
                            )}
                        </div>

                        <div class="row">
                            <span class="label">
                                Phone:
                            </span>
                            ${escapeHtml(
                                order.phone ||
                                "-"
                            )}
                        </div>

                        <div class="row">
                            <span class="label">
                                Fuel:
                            </span>
                            ${escapeHtml(
                                order.fuel ||
                                "-"
                            )}
                        </div>

                        <div class="row">
                            <span class="label">
                                Quantity:
                            </span>
                            ${escapeHtml(
                                order.quantity ||
                                "0"
                            )} L
                        </div>

                        <div class="row">
                            <span class="label">
                                Price:
                            </span>
                            ₹${escapeHtml(
                                order.price ||
                                "0"
                            )}
                        </div>

                        <div class="row">
                            <span class="label">
                                Payment:
                            </span>
                            ${escapeHtml(
                                order.payment_status ||
                                "Pending"
                            )}
                        </div>

                        <div class="row">
                            <span class="label">
                                Order Status:
                            </span>
                            ${escapeHtml(
                                order.status ||
                                "Pending"
                            )}
                        </div>

                        <div class="row">
                            <span class="label">
                                Delivery:
                            </span>
                            ${escapeHtml(
                                order.delivery_status ||
                                "Pending"
                            )}
                        </div>

                        <div class="row">
                            <span class="label">
                                Date:
                            </span>
                            ${escapeHtml(
                                order.order_date ||
                                "-"
                            )}
                        </div>
                        `;


                    ordersList.appendChild(
                        card
                    );

                }
            );

        }


        // =================================================
        // ESCAPE HTML
        // =================================================

        function escapeHtml(
            value
        ) {

            const div =
                document.createElement(
                    "div"
                );


            div.textContent =
                String(
                    value ?? ""
                );


            return div.innerHTML;

        }


        // =================================================
        // PERIOD BUTTONS
        // =================================================

        periodButtons.forEach(
            function (button) {

                button.addEventListener(
                    "click",
                    function () {

                        currentPeriod =
                            Number(
                                this.dataset.period
                            );


                        periodButtons.forEach(
                            function (item) {

                                item.classList.remove(
                                    "active"
                                );

                            }
                        );


                        this.classList.add(
                            "active"
                        );


                        loadOrders();

                    }
                );

            }
        );


        // =================================================
        // DOWNLOAD
        // =================================================

        downloadButton.addEventListener(
            "click",
            function () {

                /*
                 * Server Content-Disposition:
                 * attachment
                 * ke saath CSV bhejega.
                 *
                 * Browser ise file ke roop mein
                 * download karega.
                 */

                window.location.href =
                    "/pump-download-orders?period=" +
                    currentPeriod;

            }
        );


        // =================================================
        // CLEAR
        // =================================================

        clearButton.addEventListener(
            "click",
            async function () {

                const confirmed =
                    confirm(
                        "Clear all orders from this petrol pump history?"
                    );


                if (!confirmed) {

                    return;

                }


                clearButton.disabled =
                    true;


                clearButton.textContent =
                    "Clearing...";


                try {

                    const response =
                        await fetch(
                            "/pump-clear-orders",
                            {
                                method: "POST",

                                credentials:
                                    "same-origin",

                                cache: "no-store",

                                headers: {
                                    "Accept":
                                        "application/json",

                                    "Content-Type":
                                        "application/json"
                                },

                                body:
                                    JSON.stringify({})
                            }
                        );


                    const data =
                        await response.json();


                    if (
                        response.ok &&
                        data.success === true
                    ) {

                        await loadOrders();


                        alert(
                            "Orders cleared successfully."
                        );

                    } else {

                        alert(
                            data.message ||
                            "Unable to clear orders."
                        );

                    }


                } catch (error) {

                    console.error(
                        "Clear history error:",
                        error
                    );


                    alert(
                        "Unable to clear orders."
                    );

                } finally {

                    clearButton.disabled =
                        false;


                    clearButton.textContent =
                        "🗑️ Clear Orders";

                }

            }
        );


        // =================================================
        // FIRST LOAD
        // =================================================

        loadOrders();

    }
);