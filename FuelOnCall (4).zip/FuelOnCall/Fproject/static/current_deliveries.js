(function () {

    "use strict";


    const INTERVAL = 2000;

    let lastIds = null;

    let busy = false;


    // =====================================================
    // GET ORDER IDS
    // =====================================================

    function idsOf(deliveries) {

        return deliveries
            .map(function (item) {
                return Number(item.id);
            })
            .sort(function (a, b) {
                return a - b;
            });
    }


    // =====================================================
    // COMPARE IDS
    // =====================================================

    function sameIds(a, b) {

        return JSON.stringify(a) ===
               JSON.stringify(b);
    }


    // =====================================================
    // GPS BUTTONS
    // =====================================================

    function bindGpsButtons() {

        if (
            typeof window.startGPS !==
            "function"
        ) {
            return;
        }


        document
            .querySelectorAll(
                "[data-start-gps]"
            )
            .forEach(function (button) {

                if (
                    button.dataset.gpsBound ===
                    "1"
                ) {
                    return;
                }


                button.dataset.gpsBound =
                    "1";


                button.addEventListener(
                    "click",
                    function () {

                        window.startGPS(
                            this.getAttribute(
                                "data-start-gps"
                            )
                        );

                    }
                );

            });
    }


    // =====================================================
    // REPLACE ONLY CONTENT
    // =====================================================

    async function replaceContainer() {

        try {

            const response =
                await fetch(
                    "/current_deliveries?t=" +
                    Date.now(),
                    {
                        credentials:
                            "same-origin",

                        cache:
                            "no-store",

                        headers: {
                            "Accept":
                                "text/html"
                        }
                    }
                );


            if (!response.ok) {
                return;
            }


            const html =
                await response.text();


            const doc =
                new DOMParser()
                    .parseFromString(
                        html,
                        "text/html"
                    );


            const fresh =
                doc.querySelector(
                    ".container"
                );


            const current =
                document.querySelector(
                    ".container"
                );


            if (
                fresh &&
                current
            ) {

                current.replaceWith(
                    fresh
                );


                bindGpsButtons();
            }


        } catch (error) {

            console.error(
                "Current deliveries HTML update error:",
                error
            );
        }
    }


    // =====================================================
    // LIVE REFRESH
    // =====================================================

    async function refresh() {

        if (busy) {
            return;
        }


        busy = true;


        try {

            const response =
                await fetch(
                    "/api/current_deliveries?t=" +
                    Date.now(),
                    {
                        credentials:
                            "same-origin",

                        cache:
                            "no-store",

                        headers: {
                            "Accept":
                                "application/json",

                            "Cache-Control":
                                "no-cache",

                            "Pragma":
                                "no-cache"
                        }
                    }
                );


            if (!response.ok) {
                return;
            }


            const data =
                await response.json();


            if (
                !data ||
                data.success !== true
            ) {
                return;
            }


            const deliveries =
                data.deliveries || [];


            const ids =
                idsOf(deliveries);


            // =================================================
            // FIRST LOAD
            // =================================================

            if (lastIds === null) {

                lastIds = ids;

                bindGpsButtons();

                return;
            }


            // =================================================
            // NEW / REMOVED ORDER
            // =================================================

            if (
                !sameIds(
                    lastIds,
                    ids
                )
            ) {

                lastIds = ids;

                await replaceContainer();

                return;
            }


            // =================================================
            // UPDATE STATUS WITHOUT PAGE RELOAD
            // =================================================

            deliveries.forEach(
                function (order) {

                    const card =
                        document.querySelector(
                            '.delivery-card[data-order-id="' +
                            order.id +
                            '"]'
                        );


                    if (!card) {
                        return;
                    }


                    const status =
                        card.querySelector(
                            ".status"
                        );


                    if (status) {

                        status.textContent =
                            order.delivery_status ||
                            order.status ||
                            "Preparing";
                    }


                    // -----------------------------------------
                    // PAYMENT STATUS
                    // -----------------------------------------

                    const payment =
                        card.querySelector(
                            ".payment-status"
                        );


                    if (
                        payment &&
                        order.payment_status
                    ) {

                        payment.textContent =
                            order.payment_status;
                    }

                }
            );


        } catch (error) {

            console.error(
                "Current deliveries live update error:",
                error
            );

        } finally {

            busy = false;
        }
    }


    // =====================================================
    // START
    // =====================================================

    document.addEventListener(
        "DOMContentLoaded",
        function () {

            bindGpsButtons();

            refresh();

            setInterval(
                refresh,
                INTERVAL
            );

        }
    );


    // =====================================================
    // REFRESH WHEN TAB RETURNS
    // =====================================================

    document.addEventListener(
        "visibilitychange",
        function () {

            if (
                document.visibilityState ===
                "visible"
            ) {

                refresh();
            }
        }
    );

})();