document.addEventListener(
    "DOMContentLoaded",
    function () {


        const menuButton =
            document.getElementById(
                "menuButton"
            );


        const sideMenu =
            document.getElementById(
                "sideMenu"
            );


        const menuOverlay =
            document.getElementById(
                "menuOverlay"
            );


        // =================================================
        // MENU
        // =================================================

        function openMenu() {

            sideMenu.classList.add(
                "open"
            );

            menuOverlay.classList.add(
                "show"
            );

        }


        function closeMenu() {

            sideMenu.classList.remove(
                "open"
            );

            menuOverlay.classList.remove(
                "show"
            );

        }


        if (menuButton) {

            menuButton.addEventListener(
                "click",
                function () {

                    if (
                        sideMenu.classList.contains(
                            "open"
                        )
                    ) {

                        closeMenu();

                    } else {

                        openMenu();

                    }

                }
            );

        }


        if (menuOverlay) {

            menuOverlay.addEventListener(
                "click",
                closeMenu
            );

        }


        // =================================================
        // LIVE DASHBOARD UPDATE
        // =================================================

        async function refreshDashboard() {

            try {

                const response =
                    await fetch(
                        "/petrol_dashboard_api?t=" +
                        Date.now(),
                        {
                            method: "GET",

                            credentials:
                                "same-origin",

                            cache:
                                "no-store",

                            headers: {
                                "Accept":
                                    "application/json"
                            }
                        }
                    );


                if (!response.ok) {

                    return;

                }


                const data =
                    await response.json();


                if (
                    !data ||
                    data.success !== true
                ) {

                    return;

                }


                const newRequests =
                    document.getElementById(
                        "newRequests"
                    );


                const completedOrders =
                    document.getElementById(
                        "completedOrders"
                    );


                const todayEarnings =
                    document.getElementById(
                        "todayEarnings"
                    );


                if (newRequests) {

                    newRequests.textContent =
                        data.new_requests ?? 0;

                }


                if (completedOrders) {

                    completedOrders.textContent =
                        data.completed_orders ?? 0;

                }


                if (todayEarnings) {

                    todayEarnings.textContent =
                        "₹" +
                        (
                            data.today_earnings ??
                            0
                        );

                }


            } catch (error) {

                console.error(
                    "Dashboard live update error:",
                    error
                );

            }

        }


        // Initial update

        refreshDashboard();


        // Live update without
        // browser/page reload

        setInterval(
            refreshDashboard,
            2000
        );


    }
);
