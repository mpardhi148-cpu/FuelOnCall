import sqlite3
import os


# =========================================================
# DATABASE PATH
# =========================================================

BASE_DIR = os.path.dirname(
    os.path.abspath(__file__)
)

DATABASE_DIR = os.path.join(
    BASE_DIR,
    "Database"
)

DATABASE = os.path.join(
    DATABASE_DIR,
    "database.db"
)


# Database folder create karo
os.makedirs(
    DATABASE_DIR,
    exist_ok=True
)


print(
    "Database path:",
    DATABASE
)


# =========================================================
# CONNECT DATABASE
# =========================================================

conn = sqlite3.connect(
    DATABASE
)

cursor = conn.cursor()


# =========================================================
# USERS TABLE
# =========================================================

cursor.execute("""
CREATE TABLE IF NOT EXISTS users(

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    name TEXT NOT NULL,

    email TEXT UNIQUE NOT NULL,

    password TEXT NOT NULL,

    phone TEXT NOT NULL

)
""")


# =========================================================
# PETROL PUMPS TABLE
# =========================================================

cursor.execute("""
CREATE TABLE IF NOT EXISTS petrol_pumps(

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    pump_name TEXT NOT NULL,

    owner_name TEXT NOT NULL,

    username TEXT UNIQUE NOT NULL,

    password TEXT NOT NULL,

    phone TEXT NOT NULL,

    address TEXT NOT NULL,

    latitude REAL,

    longitude REAL,

    status TEXT DEFAULT 'Active',

    account_holder_name TEXT,

    bank_name TEXT,

    account_number TEXT,

    ifsc_code TEXT,

    upi_id TEXT,

    petrol_price REAL DEFAULT 111.21,

    diesel_price REAL DEFAULT 98.65

)
""")


# =========================================================
# ORDERS TABLE
# =========================================================

cursor.execute("""
CREATE TABLE IF NOT EXISTS orders(

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    customer_email TEXT NOT NULL,

    fuel TEXT NOT NULL,

    quantity REAL NOT NULL,

    price REAL NOT NULL,

    address TEXT NOT NULL,

    phone TEXT NOT NULL,

    payment_method TEXT DEFAULT 'Pending',

    payment_status TEXT DEFAULT 'Pending',

    status TEXT DEFAULT 'Pending Approval',

    petrol_pump_id INTEGER,

    accepted INTEGER DEFAULT 0,

    cancelled INTEGER DEFAULT 0,

    cancel_by TEXT,

    cancel_reason TEXT,

    delivery_status TEXT DEFAULT 'Pending',

    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (petrol_pump_id)
    REFERENCES petrol_pumps(id)

)
""")


# =========================================================
# COMMIT
# =========================================================

conn.commit()


# =========================================================
# CHECK TABLES
# =========================================================

cursor.execute("""
SELECT name
FROM sqlite_master
WHERE type='table'
ORDER BY name
""")


tables = cursor.fetchall()


print("\nCreated tables:")

for table in tables:

    print(
        " -",
        table[0]
    )


# =========================================================
# CLOSE
# =========================================================

conn.close()


print("✅ Database Created Successfully")